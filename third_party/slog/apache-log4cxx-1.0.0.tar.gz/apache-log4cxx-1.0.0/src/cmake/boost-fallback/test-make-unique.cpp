#include <memory>

int main(int argc, char** argv){
	std::make_unique<int>(5);
	return 0;
}
