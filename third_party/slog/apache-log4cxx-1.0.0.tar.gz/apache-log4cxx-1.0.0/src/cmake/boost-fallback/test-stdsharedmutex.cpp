#include <shared_mutex>

int main(int argc, char** argv){
	std::shared_mutex shared;
	return 0;
}
