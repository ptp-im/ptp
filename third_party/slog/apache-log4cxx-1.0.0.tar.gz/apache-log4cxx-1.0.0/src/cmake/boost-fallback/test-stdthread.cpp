#include <thread>

int main(int argc, char** argv){
	std::thread th;
	return 0;
}
