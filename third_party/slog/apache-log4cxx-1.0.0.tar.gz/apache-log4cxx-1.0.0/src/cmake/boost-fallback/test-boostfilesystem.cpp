#include <boost/filesystem.hpp>

int main(int argc, char** argv){
	boost::filesystem::path p;
}

