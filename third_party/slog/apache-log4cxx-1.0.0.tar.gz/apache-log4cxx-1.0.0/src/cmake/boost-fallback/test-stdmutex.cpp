#include <mutex>

int main(int argc, char** argv){
	std::mutex mutex;
	return 0;
}
