#include <boost/thread/shared_mutex.hpp>

int main(int argc, char** argv){
	boost::shared_mutex mtx;
	return 0;
}
