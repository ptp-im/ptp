#include <filesystem>

int main(int argc, char** argv){
	std::filesystem::path p;
}
